import test from 'node:test';
import assert from 'node:assert/strict';
import {slotsFor,moscowDate,addDays,validateBooking,escapeHtml} from '../site/core.js';
test('московская дата на границе UTC',()=>assert.equal(moscowDate(new Date('2026-11-12T22:10:00Z')),'2026-11-13'));
test('24 интервала по 20 минут, обед исключён',()=>{
  const s=slotsFor('2026-11-13',new Date('2026-11-13T00:00:00Z'));
  assert.equal(s.length,24);assert.equal(s[0],'2026-11-13T06:00:00.000Z');assert.equal(s.at(-1),'2026-11-13T14:40:00.000Z');
  assert(!s.some(t=>Date.parse(t)>=Date.parse('2026-11-13T10:00:00Z')&&Date.parse(t)<Date.parse('2026-11-13T11:00:00Z')));
});
test('нельзя выбрать прошедшее время, выходные и дату за горизонтом',()=>{
  const now=new Date('2026-11-13T07:00:00Z');assert.equal(slotsFor('2026-11-14',now).length,0);assert.equal(slotsFor('2026-11-12',now).length,0);
  assert.equal(slotsFor('2026-12-14',now).length,0);assert(slotsFor('2026-11-13',now).every(s=>new Date(s)>now));
});
test('переход месяца и проверка данных',()=>{
  assert.equal(addDays('2026-12-31',1),'2027-01-01');assert.throws(()=>validateBooking('А','Отдел','Тема'));
  assert.throws(()=>validateBooking('Иванов Иван','Отдел','x'.repeat(501)));validateBooking('Иванов Иван','Отдел','Рабочий вопрос');
});
test('пользовательский текст экранируется',()=>assert.equal(escapeHtml('<script>"&'),'&lt;script&gt;&quot;&amp;'));
